import 'dart:ui' as ui;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

const gold = Color(0xFFD9B36A);
const bg = Color(0xFF090909);
const panel = Color(0xFF171513);
const line = Color(0xFF493A25);
const apiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');

void main() => runApp(const BarberSaeedApp());

class BarberSaeedApp extends StatelessWidget {
  const BarberSaeedApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'BARBER SAEED',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: gold, secondary: gold, surface: panel),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: gold, centerTitle: true, elevation: 0),
      useMaterial3: true,
      fontFamily: 'Roboto',
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        labelStyle: const TextStyle(color: Colors.white70),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: line)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: gold)),
      ),
    ),
    home: const MainPage(),
  );
}

class Service {
  final String id, name, description, image;
  final int price, duration;
  const Service(this.id, this.name, this.description, this.price, this.duration, this.image);
}

const services = [
  Service('haircut', 'اصلاح مو', 'کوتاهی، سایه و فرم‌دهی حرفه‌ای', 150000, 30, 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=900'),
  Service('beard', 'اصلاح ریش', 'فرم‌دهی و مرتب‌سازی ریش', 100000, 20, 'https://images.unsplash.com/photo-1621607512214-68297480165e?w=900'),
  Service('facial', 'پاکسازی پوست', 'پاکسازی و رسیدگی تخصصی پوست', 200000, 45, 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=900'),
  Service('hair_beard', 'اصلاح مو و ریش', 'استایل کامل و هماهنگ', 220000, 50, 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=900'),
  Service('groom', 'گریم داماد', 'آماده‌سازی ویژه روز دامادی', 300000, 60, 'https://images.unsplash.com/photo-1599351431202-1e0f0137899a?w=900'),
  Service('special', 'خدمات ویژه', 'خدمات اختصاصی سالن', 0, 45, 'https://images.unsplash.com/photo-1517832606299-7ae9b720a186?w=900'),
];

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override State<MainPage> createState() => _MainPageState();
}
class _MainPageState extends State<MainPage> {
  int tab = 0;
  Service? selected;
  DateTime? date;
  TimeOfDay? time;
  final phone = TextEditingController();
  String money(int n) => n == 0 ? 'قیمت توافقی' : '${NumberFormat('#,###').format(n)} تومان';

  Future<void> book() async {
    if (selected == null || date == null || time == null || phone.text.trim().length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خدمت، تاریخ، ساعت و شماره موبایل را کامل کنید.'))); return;
    }
    final start = DateTime(date!.year, date!.month, date!.day, time!.hour, time!.minute);
    try {
      final response = await http.post(Uri.parse('$apiBase/api/appointments'), headers: {'Content-Type':'application/json'},
        body: jsonEncode({'customerName':'مشتری','phone':phone.text.trim(),'serviceId':selected!.id,'barberId':'saeed','startAt':start.toIso8601String()}));
      if (!mounted) return;
      if (response.statusCode == 201) {
        showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: panel, title: const Text('رزرو ثبت شد', textAlign: TextAlign.center),
          content: const Text('درخواست نوبت شما ثبت شد.', textAlign: TextAlign.center),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('متوجه شدم'))]));
      } else {
        final body = jsonDecode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(body['error'] ?? 'امکان ثبت نوبت نیست.')));
      }
    } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اتصال به سرور برقرار نشد.'))); }
  }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: ui.TextDirection.rtl, child: Scaffold(
    appBar: AppBar(toolbarHeight: 64, title: Column(children: const [Text('BARBER SAEED', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.w800, fontSize: 17)), SizedBox(height: 3), Text('SAEED SHADKAM  •  MEN’S GROOMING', style: TextStyle(color: Colors.white54, fontSize: 8, letterSpacing: 1.5))]),
      leading: IconButton(icon: const Icon(Icons.menu_rounded), onPressed: () => setState(() => tab = 3)),
      actions: [IconButton(onPressed: () => setState(() => tab = 3), icon: const Icon(Icons.person_outline_rounded))]),
    body: IndexedStack(index: tab, children: [_home(), _services(), _booking(), _profile()]),
    bottomNavigationBar: NavigationBar(height: 72, backgroundColor: const Color(0xFF12110F), indicatorColor: gold.withOpacity(.16), selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
        NavigationDestination(icon: Icon(Icons.content_cut), label: 'خدمات'),
        NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'رزرو نوبت'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
      ]),
  ));

  Widget _home() => ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
    Container(height: 285, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: gold.withOpacity(.45))),
      child: Stack(fit: StackFit.expand, children: [
        Image.network('https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=1200', fit: BoxFit.cover,
          errorBuilder: (_,__,___) => Container(color: const Color(0xFF302519))),
        DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.withOpacity(.05), Colors.black.withOpacity(.92)]))),
        Positioned(right: 20, left: 20, bottom: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: gold.withOpacity(.17), borderRadius: BorderRadius.circular(30), border: Border.all(color: gold.withOpacity(.6))), child: const Text('تجربه‌ای متفاوت از آراستگی مردانه', style: TextStyle(color: gold, fontSize: 11))),
          const SizedBox(height: 12), const Text('استایل شما،\nامضای شماست.', style: TextStyle(fontSize: 31, height: 1.35, fontWeight: FontWeight.w900, color: Colors.white)),
          const SizedBox(height: 5), const Text('سعید شادکام  |  آرایشگاه مردانه', style: TextStyle(color: Color(0xFFE6D4B4), fontSize: 13)),
        ])),
        Positioned(top: 18, right: 18, child: Container(width: 54, height: 54, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withOpacity(.55), border: Border.all(color: gold)), child: const Icon(Icons.content_cut, color: gold, size: 27))),
      ])),
    const SizedBox(height: 16),
    SizedBox(height: 58, child: FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: const Color(0xFF17120A), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      onPressed: () => setState(() => tab = 2), icon: const Icon(Icons.calendar_month), label: const Text('رزرو نوبت جدید', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)))),
    const SizedBox(height: 26), _sectionTitle('خدمات تخصصی', 'انتخاب خدمات'),
    const SizedBox(height: 12), SizedBox(height: 178, child: ListView(scrollDirection: Axis.horizontal, children: services.take(4).map(_serviceCard).toList())),
    const SizedBox(height: 24), _sectionTitle('چرا باربر سعید؟', 'کیفیت در جزئیات'),
    const SizedBox(height: 12), Row(children: const [Expanded(child: _Feature(icon: Icons.workspace_premium_outlined, title: 'کیفیت حرفه‌ای', sub: 'دقت در اجرا')), SizedBox(width: 9), Expanded(child: _Feature(icon: Icons.schedule, title: 'رزرو آسان', sub: 'بدون معطلی')), SizedBox(width: 9), Expanded(child: _Feature(icon: Icons.auto_awesome, title: 'استایل خاص', sub: 'متناسب با شما'))]),
    const SizedBox(height: 18), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: line)), child: const Row(children: [Icon(Icons.location_on_outlined, color: gold), SizedBox(width: 10), Expanded(child: Text('تهران، کیانشهر، خیابان ابراهیمی، کوچه پورکندپور، نبش بن‌بست دوم', style: TextStyle(color: Colors.white70, height: 1.7, fontSize: 12)))])),
  ]);

  Widget _sectionTitle(String title, String sub) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(title, style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)), Text(sub, style: const TextStyle(color: gold, fontSize: 11))]);
  Widget _serviceCard(Service s) => GestureDetector(onTap: () => setState(() { selected = s; tab = 2; }), child: Container(width: 145, margin: const EdgeInsets.only(left: 10), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: line)), clipBehavior: Clip.antiAlias,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Stack(fit: StackFit.expand, children: [Image.network(s.image, fit: BoxFit.cover, errorBuilder: (_,__,___) => Container(color: const Color(0xFF302519), child: const Icon(Icons.content_cut, color: gold, size: 35))), Align(alignment: Alignment.bottomCenter, child: Container(height: 45, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, panel]))))])), Padding(padding: const EdgeInsets.fromLTRB(10, 0, 10, 3), child: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))), Padding(padding: const EdgeInsets.fromLTRB(10, 0, 10, 10), child: Text(money(s.price), style: const TextStyle(color: gold, fontSize: 11))) ])));

  Widget _services() => ListView(padding: const EdgeInsets.all(16), children: [const Text('خدمات ما', style: TextStyle(fontSize: 24, color: gold, fontWeight: FontWeight.bold)), const SizedBox(height: 5), const Text('برای استایل دلخواهتان انتخاب کنید', style: TextStyle(color: Colors.white54)), const SizedBox(height: 18), ...services.map((s) => _serviceRow(s))]);
  Widget _serviceRow(Service s) {
    return GestureDetector(
      onTap: () => setState(() {
        selected = s;
        tab = 2;
      }),
      child: Container(
        height: 112,
        margin: const EdgeInsets.only(bottom: 13),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: panel,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: line),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 112,
              height: 112,
              child: Image.network(
                s.image,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const ColoredBox(
                  color: Color(0xFF302519),
                  child: Icon(Icons.content_cut, color: gold),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(s.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 5),
                    Text(
                      s.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Text(money(s.price), style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        Text('${s.duration} دقیقه', style: const TextStyle(color: Colors.white54, fontSize: 10)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(10),
              child: Icon(Icons.chevron_left, color: gold),
            ),
          ],
        ),
      ),
    );
  }

  Widget _booking() => ListView(padding: const EdgeInsets.all(20), children: [const Text('رزرو نوبت', style: TextStyle(fontSize: 24, color: gold, fontWeight: FontWeight.bold)), const SizedBox(height: 5), const Text('در چند قدم، نوبت خود را ثبت کنید.', style: TextStyle(color: Colors.white54)), const SizedBox(height: 22), _label('۱. انتخاب خدمت'), DropdownButtonFormField<Service>(value: selected, dropdownColor: panel, decoration: const InputDecoration(labelText: 'خدمت موردنظر'), items: services.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(), onChanged: (v) => setState(() => selected = v)), const SizedBox(height: 18), _label('۲. انتخاب تاریخ'), OutlinedButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 90))); if (d != null) setState(() => date = d); }, icon: const Icon(Icons.date_range), label: Text(date == null ? 'انتخاب تاریخ' : DateFormat('yyyy/MM/dd').format(date!))), const SizedBox(height: 14), _label('۳. انتخاب ساعت'), OutlinedButton.icon(onPressed: () async { final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 10, minute: 0)); if (t != null) setState(() => time = t); }, icon: const Icon(Icons.access_time), label: Text(time == null ? 'انتخاب ساعت' : time!.format(context))), const SizedBox(height: 18), _label('۴. شماره موبایل'), TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: '09xxxxxxxxx')), const SizedBox(height: 18), if (selected != null) Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: line)), child: Row(children: [const Text('مبلغ قابل پرداخت', style: TextStyle(color: Colors.white70)), const Spacer(), Text(money(selected!.price), style: const TextStyle(color: gold, fontWeight: FontWeight.bold))])), const SizedBox(height: 20), SizedBox(height: 54, child: FilledButton(onPressed: book, child: const Text('ثبت درخواست رزرو', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)))), const SizedBox(height: 12), const Text('پرداخت در حال حاضر به‌صورت حضوری در سالن انجام می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 11))]);
  Widget _label(String s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(s, style: const TextStyle(color: gold, fontWeight: FontWeight.bold)));
  Widget _profile() => ListView(padding: const EdgeInsets.all(20), children: [const SizedBox(height: 15), const CircleAvatar(radius: 42, backgroundColor: panel, child: Icon(Icons.person_outline, color: gold, size: 42)), const SizedBox(height: 14), const Center(child: Text('حساب کاربری', style: TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.bold))), const SizedBox(height: 8), const Center(child: Text('برای مشاهده سوابق و مدیریت نوبت‌ها وارد شوید.', style: TextStyle(color: Colors.white54), textAlign: TextAlign.center)), const SizedBox(height: 24), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: line)), child: const Column(children: [ListTile(leading: Icon(Icons.history, color: gold), title: Text('سوابق نوبت‌ها'), subtitle: Text('به‌زودی فعال می‌شود')), Divider(color: line), ListTile(leading: Icon(Icons.call_outlined, color: gold), title: Text('تماس با سالن'), subtitle: Text('09355771317'))]))]);
}

class _Feature extends StatelessWidget {
  final IconData icon; final String title, sub;
  const _Feature({required this.icon, required this.title, required this.sub});
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 5), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: line)), child: Column(children: [Icon(icon, color: gold, size: 25), const SizedBox(height: 8), Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(sub, style: const TextStyle(fontSize: 9, color: Color(0x73FFFFFF)))]));
}
